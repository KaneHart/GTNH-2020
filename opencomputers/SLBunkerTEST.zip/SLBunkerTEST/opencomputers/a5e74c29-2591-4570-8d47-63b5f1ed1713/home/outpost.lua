local component = require("component")
local sg = component.getPrimary("stargate")
local sides = require("sides")
local term = require("term")

local curbunker = 1
local owgate = ""

bunker = {
  { "A", "AAA5-KI7-VR"},
  { "B", "YAAZ-EOJ-YI"},
  { "C", "MAAN-8OP-C7"},
  { "D", "AAA5-KI7-VR"},
  { "E", "YAAZ-EOJ-YI"},
  { "F", "MAAN-8OP-C7"},
  { "G", "AAA5-KI7-VR"},
  { "H", "YAAZ-EOJ-YI"},
  { "I", "MAAN-8OP-C7"}
}

function dialow()
  print(os.date("%c"))
  sg.dial(owgate)
end

function main()
  term.clear()
  owgate = bunker[curbunker][2]
  print (owgate)
  while true do
    if component.redstone.getInput(sides.back) == 15 then dialow()
    end
    os.sleep(5)
    print("...")
  end
end

main()